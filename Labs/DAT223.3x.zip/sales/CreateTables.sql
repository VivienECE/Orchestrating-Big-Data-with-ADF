CREATE TABLE Orders
(OrderDate datetime,
 OrderID int,
 CustomerID int,
 CustomerName nvarchar(100),
 Total decimal);


 CREATE TABLE LineItems
 (OrderID int,
  OrderLineID int,
  StockItemID int,
  StockItemName nvarchar(100),
  Quantity int,
  UnitPrice decimal,
  LineTotal decimal);